package com.ectrip.model;

public class Sysparv5 {
    private String pmky;

    private String pmcd;

    private String spmcd;

    private String systp;

    private String pmva;

    private String pmvb;

    private String pmvc;

    private String pmvd;

    private String pmve;

    private String pmvf;

    private Integer isa;

    private Integer isb;

    private Integer isc;

    private Integer isd;

    private Integer ise;

    private Integer isf;

    private Integer isvalue;

    private String note;

    private String dtmakedate;

    public String getPmky() {
        return pmky;
    }

    public void setPmky(String pmky) {
        this.pmky = pmky == null ? null : pmky.trim();
    }

    public String getPmcd() {
        return pmcd;
    }

    public void setPmcd(String pmcd) {
        this.pmcd = pmcd == null ? null : pmcd.trim();
    }

    public String getSpmcd() {
        return spmcd;
    }

    public void setSpmcd(String spmcd) {
        this.spmcd = spmcd == null ? null : spmcd.trim();
    }

    public String getSystp() {
        return systp;
    }

    public void setSystp(String systp) {
        this.systp = systp == null ? null : systp.trim();
    }

    public String getPmva() {
        return pmva;
    }

    public void setPmva(String pmva) {
        this.pmva = pmva == null ? null : pmva.trim();
    }

    public String getPmvb() {
        return pmvb;
    }

    public void setPmvb(String pmvb) {
        this.pmvb = pmvb == null ? null : pmvb.trim();
    }

    public String getPmvc() {
        return pmvc;
    }

    public void setPmvc(String pmvc) {
        this.pmvc = pmvc == null ? null : pmvc.trim();
    }

    public String getPmvd() {
        return pmvd;
    }

    public void setPmvd(String pmvd) {
        this.pmvd = pmvd == null ? null : pmvd.trim();
    }

    public String getPmve() {
        return pmve;
    }

    public void setPmve(String pmve) {
        this.pmve = pmve == null ? null : pmve.trim();
    }

    public String getPmvf() {
        return pmvf;
    }

    public void setPmvf(String pmvf) {
        this.pmvf = pmvf == null ? null : pmvf.trim();
    }

    public Integer getIsa() {
        return isa;
    }

    public void setIsa(Integer isa) {
        this.isa = isa;
    }

    public Integer getIsb() {
        return isb;
    }

    public void setIsb(Integer isb) {
        this.isb = isb;
    }

    public Integer getIsc() {
        return isc;
    }

    public void setIsc(Integer isc) {
        this.isc = isc;
    }

    public Integer getIsd() {
        return isd;
    }

    public void setIsd(Integer isd) {
        this.isd = isd;
    }

    public Integer getIse() {
        return ise;
    }

    public void setIse(Integer ise) {
        this.ise = ise;
    }

    public Integer getIsf() {
        return isf;
    }

    public void setIsf(Integer isf) {
        this.isf = isf;
    }

    public Integer getIsvalue() {
        return isvalue;
    }

    public void setIsvalue(Integer isvalue) {
        this.isvalue = isvalue;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note == null ? null : note.trim();
    }

    public String getDtmakedate() {
        return dtmakedate;
    }

    public void setDtmakedate(String dtmakedate) {
        this.dtmakedate = dtmakedate == null ? null : dtmakedate.trim();
    }
}