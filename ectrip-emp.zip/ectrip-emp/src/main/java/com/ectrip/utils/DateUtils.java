package com.ectrip.utils;

import org.apache.commons.lang3.StringUtils;

import java.sql.Time;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 实现描述：时间操作工具类
 *
 * @version v1.0.0
 * @since 13-8-12上午10:37
 */
public class DateUtils {
    public final static String DATE_CHINESE_PATTERN = "yyyy年MM月dd日";
    /**
     * 标准日期格式
     */
    public final static String DATE_PATTERN = "yyyy-MM-dd";

    public final static String DATE_SHORT_PATTERN = "yyyyMMdd";

    public final static String DATE_SLASH_PATTERN = "yyyy/MM/dd";

    /**
     * 标准日期时分秒毫秒格式
     */
    public final static String DATETIME_MILL_SECOND = "yyyy-MM-dd HH:mm:ss.SSS";

    /**
     * 标准时间格式
     */
    public final static String DATETIME_PATTERN = "yyyy-MM-dd HH:mm:ss";

    /**
     * 特殊的格式 针对创建订单，拼凑的最晚支付时间
     */
    public final static String DATETIME_PATTERN_CREAT_ORDER = "yyyy-MM-dd HH:mm";

    public final static String DATETIME_CHINESS = "yyyy年-MM月-dd日 EEEE";

    public final static String DATETIME_SHORT_PATTERN = "yyyyMMddHHmmss";

    /**
     * 标准年小时分钟格式
     */
    public final static String HOUR_MINUTE = "HH:mm";

    /**
     * 标准年小时分钟秒格式
     */
    public final static String HOUR_MINUTE_SECOND = "HH:mm:ss";

    /**
     * Number of milliseconds in a standard day.
     */
    public static final long MILLIS_PER_DAY = 24 * DateUtils.MILLIS_PER_HOUR;

    /**
     * Number of milliseconds in a standard hour.
     */
    public static final long MILLIS_PER_HOUR = 60 * DateUtils.MILLIS_PER_MINUTE;

    /**
     * Number of milliseconds in a standard minute.
     */
    public static final long MILLIS_PER_MINUTE = 60 * DateUtils.MILLIS_PER_SECOND;

    /**
     * Number of milliseconds in a standard second.
     */
    public static final long MILLIS_PER_SECOND = 1000;

    /**
     * 一小时是多少分钟
     */
    public static final int MINUTES_OF_AN_HOUR = 60;

    /**
     * 标准年月格式
     */
    public final static String MONTH_PATTERN = "yyyy-MM";

    private final static String[] WEEK_NAMES = {"星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期天"};

    /**
     * 每天开始时间
     */
    public final static String TIME_START = "00:00:00";

    /**
     * 每天截止时间
     */
    public final static String TIME_END = "23:59:59";

    /**
     * 在指定日期增加：天数
     *
     * @param date 指定日期
     * @param days 指定天数
     * @return
     */
    public static Date addDay(Date date, int days) {
        if (days == 0) {
            return date;
        }
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DAY_OF_YEAR, days);
        return c.getTime();
    }

    /**
     * 在指定日期增加：月数
     *
     * @param date   指定日期
     * @param months 指定月数
     * @return
     */
    public static Date addMonth(Date date, int months) {
        if (months == 0) {
            return date;
        }
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.MONTH, months);
        return c.getTime();
    }

    public static Date addYear(Date date, int years) {
        if (0 == years) {
            return date;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.YEAR, years);
        return calendar.getTime();
    }

    public static void main(String[] args) {
        System.out.println(getTodayStr());
    }

    /**
     * 获取当前时间
     * 格式： String
     */
    public static String getTodayStr() {
        String nowString = "";
        String monthString = "";
        String dayString = "";
        String hourString = "";
        String minString = "";
        String secString = "";

        Calendar now = Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
        nowString = nowString + now.get(1) + "-";
        Integer month = now.get(2) + 1;
        if (month < 10) {
            monthString = "0" + month;
        } else {
            monthString = month.toString();
        }

        Integer day = now.get(5);
        if (day < 10) {
            dayString = "0" + day;
        } else {
            dayString = day.toString();
        }

        nowString = nowString + monthString + "-" + dayString;

        Integer hour = now.get(11);
        if (hour < 10) {
            hourString = "0" + hour;
        } else {
            hourString = hour.toString();
        }

        nowString = nowString + " " + hourString;
        Integer min = now.get(12);
        if (min < 10) {
            minString = "0" + min;
        } else {
            minString = min.toString();
        }

        nowString = nowString + ":" + minString;
        Integer sec = now.get(13);
        if (sec < 10) {
            secString = "0" + sec;
        } else {
            secString = sec.toString();
        }

        nowString = nowString + ":" + secString;
        return nowString;
    }

    /**
     * 获取当前时间
     * 格式： Date
     */
    public static Date getTodayDate() {
        return convertDate(getTodayStr(), DATETIME_PATTERN);
    }

    /**
     * 获取当前时间 : 根据规范格式
     */
    public static Date getTodayDate(String pattern) {
        return convertDate(getTodayStr(), pattern);
    }


    /**
     * 获取当前: 时分秒
     */
    public static String getTodayTime() {
        return getTodayStr().substring(11);
    }

    /**
     * 在指定日期增加：小时
     *
     * @param date 指定日期
     * @param hour 指定小时
     * @return
     */
    public static Date addHour(Date date, int hour) {
        if (hour == 0) {
            return date;
        }
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.HOUR, hour);
        return c.getTime();
    }

    /**
     * 在指定日期增加指定天数
     *
     * @param date 指定日期
     * @param days 指定天数
     * @return
     */
    public static Date addDay(String date, int days) {
        return DateUtils.addDay(DateUtils.convertDate(date), days);
    }

    public static Date addMinute(Date date, int minute) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.MINUTE, minute);
        return c.getTime();
    }

    /**
     * 当前日期之后
     *
     * @param date
     * @return
     */
    public static boolean afterToday(Object date) {
        Date currentDate = getTodayDate();
        return DateUtils.compareDate(date, currentDate) == 1;
    }

    /**
     * 当前时间之后
     *
     * @param date
     * @return
     */
    public static boolean afterTodayDate(Date date) {
        Date currentDate = getTodayDate();
        return currentDate.compareTo(date) == -1;
    }

    /**
     * 当前日期之前
     *
     * @param date
     * @return
     */
    public static boolean beforeToday(Object date) {
        Date currentDate = getTodayDate();
        return DateUtils.compareDate(date, currentDate) == -1;
    }

    /**
     * 当前时间之前
     *
     * @param date
     * @return
     */
    public static boolean beforeTodayDate(Date date) {
        Date currentDate = getTodayDate();
        return currentDate.compareTo(date) == 1;
    }

    /**
     * 比较两个日期date1大于date2 返回1 等于返回0 小于返回-1
     *
     * @param date1
     * @param date2
     * @return
     */
    public static int compareDate(Object date1, Object date2) {
        if (date1 == null || date2 == null) {
            String msg = "illegal arguments,date1 and date2 must be not null.";
            throw new IllegalArgumentException(msg);
        }
        Date d1 = (Date) (date1 instanceof String ? DateUtils.convertDate((String) date1) : date1);
        Date d2 = (Date) (date2 instanceof String ? DateUtils.convertDate((String) date2) : date2);
        return d1.compareTo(d2);
    }

    /**
     * 目标日期是否在给定2个日期之间 包含当天
     *
     * @param before 开始日期
     * @param target 目标日期
     * @param after  截止日期
     * @return
     */
    public static boolean between2Date(Date before, Date target, Date after) {
        int afterState = compareDate(target, before);
        int beforeState = compareDate(after, target);
        if (afterState >= 0 && beforeState >= 0) {
            return true;
        }
        return false;
    }


    /**
     * 目标时间是否在给定2个时间之间 包含一头一尾
     *
     * @param before 起始时间
     * @param target 目标时间
     * @param after  截止时间
     * @return
     */
    public static boolean between2Time(String before, String target, String after) {
        long now = convertDate(target, HOUR_MINUTE_SECOND).getTime();
        long start = convertDate(before, HOUR_MINUTE_SECOND).getTime();
        long end = convertDate(after, HOUR_MINUTE_SECOND).getTime();
        if (now >= start && now <= end) {
            return true;
        }
        return false;
    }

    /**
     * 判断2个日期前后
     *
     * @param d1 前一个日期
     * @param d2 后一个日期
     * @return d2<=d1 true
     */
    public static boolean dateAfter(Date d1, Date d2) {
        return d1.after(d2);
    }

    public static Date convertDate(Date date, String pattern) {
        if (StringUtils.isEmpty(pattern)) {
            String msg = "the date or pattern is empty.";
            throw new IllegalArgumentException(msg);
        }
        String dateForPattern = DateUtils.formatDate(date, pattern);
        return DateUtils.convertDate(dateForPattern, pattern);
    }

    /**
     * 将long型整数转化为时间。
     *
     * @param date 时间对应的long值
     * @return 时间对象
     */
    public static Date convertDate(Long date) {
        return new Date(date);
    }

    /**
     * 将日期或者时间戳转化为日期对象
     *
     * @param date yyyy-MM-dd or yyyy-MM-dd HH:mm:ss or yyyy-MM-dd HH:mm:ss.SSS
     * @return
     */
    public static Date convertDate(String date) {
        if (StringUtils.isBlank(date)) {
            return null;
        }
        if (date.indexOf(":") > 0) {
            return DateUtils.convertDate(date, DateUtils.DATETIME_PATTERN);
        } else if (date.indexOf(".") > 0) {
            return DateUtils.convertDate(date, DateUtils.DATETIME_MILL_SECOND);
        } else {
            return DateUtils.convertDate(date, DateUtils.DATE_PATTERN);
        }
    }

    /**
     * 将日期或者时间字符串转化为日期对象
     *
     * @param date    日期字符串
     * @param pattern 格式字符串</br> yyyy-MM-DD, yyyy/MM/DD, yyyyMMdd</br> yyyy-MM-dd-HH:mm:ss, yyyy-MM-dd HH:mm:ss
     *                格式字符串可选字符："GyMdkHmsSEDFwWahKzZ"
     * @return Date
     */
    public static Date convertDate(String date, String pattern) {
        try {
            if (StringUtils.isEmpty(pattern) || StringUtils.isEmpty(date)) {
                String msg = "the date or pattern is empty.";
                throw new IllegalArgumentException(msg);
            }
            SimpleDateFormat df = new SimpleDateFormat(pattern.trim());
            return df.parse(date.trim());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 将时间字符串转化为时间对象Time
     *
     * @param time    时间字符串
     * @param pattern 格式字符串 yyyy-MM-dd HH:mm:ss or yyyy-MM-dd HH:mm:ss.SSS
     * @return
     */
    public static Time convertTime(String time, String pattern) {
        Date d = DateUtils.convertDate(time, pattern);
        return new Time(d.getTime());
    }

    /**
     * 获得日期相差天数
     *
     * @param date1 日期
     * @param date2 日期
     * @return
     */
    public static int diffDate(Date date1, Date date2) {
        return (int) ((date1.getTime() - date2.getTime()) / DateUtils.MILLIS_PER_DAY);
    }

    /**
     * 获得日期相差月数
     *
     * @param date1 日期
     * @param date2 日期
     * @return
     */
    public static int diffMonth(String date1, String date2) {
        int result = 0;

        Calendar c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();

        c1.setTime(getDateFromShortString(date1));
        c2.setTime(getDateFromShortString(date2));

        result = c2.get(Calendar.MONDAY) - c1.get(Calendar.MONTH);

        return result == 0 ? 1 : Math.abs(result);
    }

    /**
     * 获取两个日期相差的分钟数
     *
     * @param date1
     * @param date2
     * @return
     */
    public static int diffMinute(Date date1, Date date2) {
        return (int) ((date1.getTime() - date2.getTime()) / DateUtils.MILLIS_PER_MINUTE);
    }

    /**
     * 格式为时间字符串
     *
     * @param date 日期
     * @return yyyy-MM-dd Date
     */
    public static String formatDate(Date date) {
        try {
            return DateUtils.formatDate(date, DateUtils.DATE_PATTERN);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 按指定格式字符串格式时间
     *
     * @param date    日期或者时间
     * @param pattern 格式化字符串 yyyy-MM-dd， yyyy-MM-dd HH:mm:ss, yyyy年MM月dd日 etc.</br>
     * @return
     */
    public static String formatDate(Date date, String pattern) {
        SimpleDateFormat format = new SimpleDateFormat(pattern.trim());
        return format.format(date);
    }

    public static String formatDate(Date date, String pattern, Locale locale) {
        SimpleDateFormat format = new SimpleDateFormat(pattern.trim(), locale);
        return format.format(date);
    }

    public static String formatDate(String date, String pattern) {
        SimpleDateFormat format = new SimpleDateFormat(pattern.trim());
        return format.format(convertDate(date, pattern));
    }

    /**
     * 格式为时间戳字符串
     *
     * @param date 时间
     * @return yyyy-MM-dd HH:mm:ss Date
     */
    public static String formatDateTime(Date date) {
        try {
            return DateUtils.formatDate(date, DateUtils.DATETIME_PATTERN);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 将制定时间格式为字符串'yyyyMMddHHmmss'.
     *
     * @return
     */
    public static String formatDateToYMDHMS(Date date) {
        return DateUtils.formatDate(date, DateUtils.DATETIME_SHORT_PATTERN);
    }

    /**
     * 将制定时间格式为字符串'HHmmss'.
     *
     * @param date
     * @return
     */
    public static String formatDateToHMS(Date date) {
        return DateUtils.formatDate(date, DateUtils.HOUR_MINUTE_SECOND);
    }

    public static String formatMonth(Date date) {
        return DateUtils.formatDate(date, DateUtils.MONTH_PATTERN);
    }

    /**
     * 将当前时间格式为字符串'yyyyMMddHHmmss'.
     *
     * @return
     */
    public static String formatNowToYMDHMS() {
        return DateUtils.formatDateToYMDHMS(getTodayDate());
    }

    /**
     * 将当前时间格式为字符串'HHmmss'
     *
     * @return
     */
    public static String formatNowToHMS() {
        return DateUtils.formatDateToHMS(getTodayDate());
    }

    public static Timestamp getCurrentTimestamp() {
        return new Timestamp(getTodayDate().getTime());
    }

    public static Date getDateFromShortString(String str) {
        SimpleDateFormat simpleDF = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return simpleDF.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获得本周第一天
     *
     * @param date
     * @return
     */
    public static Date getFirstDayOfThisWeek(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.setFirstDayOfWeek(Calendar.MONDAY);
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        return cal.getTime();
    }

    /**
     * 获得小时
     *
     * @param date
     * @return
     */
    public static int getHourOfDay(Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        return c.get(Calendar.HOUR_OF_DAY);
    }

    public static Date getLastMonth() {
        Calendar c = Calendar.getInstance();
        int month = c.get(Calendar.MONTH);
        c.set(Calendar.MONTH, month - 1);
        return c.getTime();
    }

    /**
     * 获得分钟数
     *
     * @param date
     * @return
     */
    public static int getMinute(Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        return c.get(Calendar.MINUTE);
    }

    /**
     * 获取后续第n天日期
     *
     * @param date
     * @param n    第n天
     * @return
     */
    public static Date getNextNDay(Date date, int n) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, n);
        return cal.getTime();
    }

    /**
     * 获得星期数
     *
     * @param date 日期
     * @return
     */
    public static int getOrignWeekNumber(Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        int number = c.get(Calendar.DAY_OF_WEEK) - 1;
        return number;
    }

    /**
     * 获得星期数
     *
     * @param date 日期
     * @return
     */
    public static int getWeekNumber(Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        int number = c.get(Calendar.DAY_OF_WEEK) - 1;
        if (number == 0) {
            number = 7;
        }
        return number;
    }

    /**
     * 获得星期名称
     *
     * @param date
     * @return
     */
    public static String getWeekNumberString(Date date) {
        int dayNum = DateUtils.getWeekNumber(date);
        return DateUtils.WEEK_NAMES[dayNum - 1];
    }

    /**
     * 是否同一天
     *
     * @param date1
     * @param date2
     * @return
     */
    public static boolean isSameDay(Object date1, Object date2) {
        return DateUtils.compareDate(date1, date2) == 0;
    }

    /**
     * 检查时间或者字符串是否合法
     *
     * @param date    时间
     * @param pattern 格式串
     * @return
     */
    public static boolean isValidDate(String date, String pattern) {
        try {
            DateUtils.convertDate(pattern, date);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 获得当前时间戳
     *
     * @return Timestamp
     */
    public static Timestamp now() {
        return new Timestamp(getTodayDate().getTime());
    }

    /**
     * 获得当前时间字符串,格式为：yyyy-MM-dd HH:mm:ss
     *
     * @return
     */
    public static String nowDateTime() {
        return DateUtils.formatDate(getTodayDate(), DateUtils.DATETIME_PATTERN);
    }

    /**
     * 按指定roundType格式化日期。
     *
     * @param date      日期
     * @param roundType
     * @return Date
     */
    public static Date round(Date date, int roundType) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(date.getTime());
        switch (roundType) {
            case Calendar.MONTH:
                c.set(Calendar.DAY_OF_MONTH, 1);
            case Calendar.DATE:
                c.set(Calendar.HOUR_OF_DAY, 0);
            case Calendar.HOUR:
                c.set(Calendar.MINUTE, 0);
            case Calendar.MINUTE:
                c.set(Calendar.SECOND, 0);
            case Calendar.SECOND:
                c.set(Calendar.MILLISECOND, 0);
                return c.getTime();
            default:
                throw new IllegalArgumentException("invalid round roundType.");
        }
    }

    /**
     * 获得当前日期对象
     *
     * @return
     */
    public static Date today() {
        return DateUtils.convertDate(DateUtils.formatDate(getTodayDate()), DateUtils.DATE_PATTERN);
    }

    /**
     * 获得当前日期字符串,格式为：yyyy-MM-dd
     *
     * @return
     */
    public static String todayDate() {
        return DateUtils.formatDate(getTodayDate());
    }

    /**
     * 明天的日期
     *
     * @return
     */
    public static String tomorrowDate() {
        return DateUtils.formatDate(addDay(new Date(), 1));
    }

    /**
     * 将日期或者时间字符串转化为Timestamp对象
     *
     * @param date    日期字符串
     * @param pattern 格式字符串</br> yyyy-MM-DD, yyyy/MM/DD, yyyyMMdd</br> yyyy-MM-dd-HH:mm:ss, yyyy-MM-dd HH:mm:ss
     * @return Timestamp
     * @author reeboo
     */
    public static Timestamp toTimestamp(String date, String pattern) {
        SimpleDateFormat format = new SimpleDateFormat(pattern.trim());
        try {
            return new Timestamp(format.parse(date).getTime());
        } catch (ParseException e) {
        }
        return null;
    }

    /**
     * 获得当天日期
     * Describe:
     *
     * @return return:String 日期 yyyy-MM-dd
     * Date:2014-5-26
     * @author:hezhihong
     */
    public static String getDays() {
        return getTodayStr().substring(0, 10);
    }

    /**
     * Describe:当前月剩余天数
     *
     * @param date
     * @param split 日期分割分
     * @return return:List<String>
     * Date:2014-6-27
     * @author:zhangwubin
     */
    public static List<String> getSurplusDate(Date date, String split) {
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        int year = c.get(c.YEAR);
        int month = c.get(c.MONTH) + 1;
        int day = c.get(c.DATE);
        int maxday = c.getActualMaximum(Calendar.DAY_OF_MONTH);
        List<String> list = new ArrayList<String>();
        for (int i = 0; i <= maxday - day; i++) {
            int num = day + i;
            list.add(year + split + (month < 10 ? "0" + month : month) + split + (num < 10 ? "0" + num : num));
        }
        return list;
    }

    /**
     * Describe:获取当前日期月所指定的星期的所有日期
     *
     * @param date
     * @param week
     * @return return:List<String>
     * Date:2014-7-11
     * @author:zhangwubin
     */
    public static List<String> getDateByWeek(Date date, int week) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.set(Calendar.DAY_OF_MONTH, 1);
        int day = c.getMaximum(Calendar.DAY_OF_MONTH);
        List<String> list = new ArrayList<String>();
        for (int i = 0; i < day; i++) {
            if (c.get(Calendar.DAY_OF_WEEK) == week) {
                list.add(formatDate(c.getTime()));
            }
            c.add(Calendar.DAY_OF_MONTH, 1);
        }
        return list;
    }

    /**
     * Describe:获得两个日期之间的所有天数，不包含开始和结束时间
     *
     * @param startDate
     * @param endDate
     * @return return:List<String>
     * Date:2014-7-11
     * @author:zhangwubin
     */
    public static List<String> getTimeDifference(String startDate, String endDate) {
        List<String> list = new ArrayList<String>();
        if (startDate.equals(endDate)) {
            list.add(startDate);
            return list;
        }
        if (compareDate(endDate, startDate) == -1) {
            return null;
        }
        Date sDate = getDateFromShortString(startDate);
        Date eDate = getDateFromShortString(endDate);
        while (compareDate(sDate, eDate) == -1) {
            list.add(formatDate(sDate));
            sDate = addDay(sDate, 1);
        }
        list.remove(0);
        return list;
    }

    /**
     * 获得日期相差月数
     *
     * @param date1 日期
     * @param date2 日期
     * @return
     * @author:zhangwubin
     */
    public static int differMonth(String date1, String date2) {
        int result = 0;

        Calendar c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();

        c1.setTime(getDateFromShortString(date1));
        c2.setTime(getDateFromShortString(date2));
        result = c2.get(Calendar.MONTH) - c1.get(Calendar.MONTH);
        return Math.abs(result);
    }

    /**
     * 分钟转小时
     *
     * @param minutes 分钟数
     * @return 小时数
     */
    public static int minutesToHour(int minutes) {
        int hour = minutes / MINUTES_OF_AN_HOUR;
        if (minutes % MINUTES_OF_AN_HOUR != 0) {
            hour += 1;
        }
        return hour;
    }

    /**
     * 获取某个日期的最后一天
     *
     * @param date 日期字符串
     * @return 返回最后一天
     */
    public static String getLastDayOfMonth(Object date) {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        if (date instanceof String) {
            try {

                cal.setTime(format.parse((String) date));
            } catch (ParseException pe) {
                throw new IllegalArgumentException("date parse error :" + date);
            }
        } else if (date instanceof Date) {
            cal.setTime((Date) date);
        } else {
            throw new IllegalArgumentException("date format error : " + date);
        }
        //获取某月最大天数
        int lastDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        //设置日历中月份的最大天数
        cal.set(Calendar.DAY_OF_MONTH, lastDay);
        return format.format(cal.getTime());
    }

    /*
     * 将时间转换为时间戳
     */
    public static String dateToStamp(String s, String format) throws ParseException {
        String res;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        Date date = simpleDateFormat.parse(s);
        long ts = date.getTime();
        res = String.valueOf(ts);
        return res;
    }

    /**
     * 时间戳转日期
     * @param timestamp
     * @param format yyyy-mm-dd 或者其他格式
     * @return
     * @throws ParseException
     */
    public static String timestampToDateStr(long timestamp, String format) throws ParseException {
        return formatDate(new Date(timestamp), format);
    }

    /**
     * 时间戳转日期
     * @param timestamp
     * @return yyyy-mm-dd
     * @throws ParseException
     */
    public static String timestampToDateStr(long timestamp) throws ParseException {
        return timestampToDateStr(timestamp,DATE_PATTERN);
    }
}
